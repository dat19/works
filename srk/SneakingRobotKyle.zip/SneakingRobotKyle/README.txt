==============================================================================
ゲーム名：スニーキングカイル
動作環境：<Windows10の実行ファイル / WebGL>
公開先　：<https://unityroom.com/games/escapekyle>
==============================================================================

◆ゲーム概要(1～2行程度で簡潔に)
敵に見つからないようにゴールへたどり着きましょう。

敵の視界判定のテストとして作成。
又、敵の行動パターンの作成や、その制御を作って見たかったため作成しました。


◆起動方法
Windows版・・・RobotKyle.exe をダブルクリック

WebGL版・・・・ https://unityroom.com/games/escapekyle


◆操作方法
W：上方向に移動
A：左方向に移動
S：下方向に移動
D；右方向に移動
LeftShiftを押しながら移動でダッシュ。
Spaceキー : コンソールの操作。
Fキー : エネミーをおびき出すアイテム投擲。

◆ルール
敵に見つからないようにキーを拾い、ゴールのゲートまでたどり着く。
敵に見つかるとゲームオーバー。


◆使用アセット名とURL
・UnityAssetStore
Space Robot Kyle
 <https://assetstore.unity.com/packages/3d/characters/robots/space-robot-kyle-4696>

Dungeon Skeletons Demo
 <https://assetstore.unity.com/packages/3d/characters/creatures/dungeon-skeletons-demo-71087>

Yughues Free Metal Materials
 <https://assetstore.unity.com/packages/2d/textures-materials/metals/yughues-free-metal-materials-12949>

Grenade Sound FX
 <https://assetstore.unity.com/packages/audio/sound-fx/grenade-sound-fx-147490>

Basic Motions FREE Pack
 <https://assetstore.unity.com/packages/3d/animations/basic-motions-free-pack-154271>

Selected U3D Japanese Font
 <https://assetstore.unity.com/packages/2d/fonts/selected-u3d-japanese-font-337>

・サウンド
魔王魂
 <https://maoudamashii.jokersounds.com/>

効果音ラボ
 <https://soundeffect-lab.info/>

OtoLogic
 <https://otologic.jp/>

◆開発メンバーと担当作業
原田　聖也
・プログラム
