==============================================================================
ゲーム名：アニマルカジノ
動作環境：Windows10の実行ファイル
==============================================================================

◆ゲーム概要(1～2行程度で簡潔に)
ゆるキャラたちがギャンブルをして
沼にハマっていくゲーム

◆起動方法
AnimalCasino.exe をダブルクリック

◆操作方法
 マウス操作

◆ルール
ゲームに勝利し、お金を集める

◆使用アセット名とURL
Unityアセット
 Simple City pack
　https://assetstore.unity.com/packages/3d/environments/urban/simple-city-pack-plain-100348

BGM
 DOVA-SYNDROME
  https://dova-s.jp/bgm/play10441.html
  https://dova-s.jp/bgm/play1800.html
  https://dova-s.jp/bgm/play13173.html
  https://dova-s.jp/bgm/play115.html

◆開発メンバーと担当作業
グラフィック
  鴻上 里咲 (UI、ツリスキー・Josephine)
  形屋 裕斗 (UI、背景)
  高橋 彩奈 (UI、しばすけ・めりーず)
  田中 美優 (UI、背景)
システム
  小林 アレクシー (メニューシーン)
  並木 翔汰 (シナリオシーン)
  野沢 龍生 (ゲームシーン)

