==============================================================================
ゲーム名：Flying in the Sky
動作環境：Windows10の実行ファイル
==============================================================================

◆ゲーム概要(1～2行程度で簡潔に)

島のどこかにあるリングを取ろう

◆起動方法
Flying In The Sky.exe をダブルクリック

◆操作方法

Ｗキー(↑)：飛行機の下降
Ｓキー(↓)：飛行機の上昇
Ａキー(←)：左旋回
Ｄキー(→)：右旋回

◆ルール

できるだけ早くリングをとる

◆使用アセット名とURL

Standard Assets (for Unity 2018.4)
https://assetstore.unity.com/packages/essentials/asset-packs/standard-assets-for-unity-2018-4-32351

Terrain Toolkit 2017
https://assetstore.unity.com/packages/tools/terrain/terrain-toolkit-2017-83490

Simple City pack plain
https://assetstore.unity.com/packages/3d/environments/urban/simple-city-pack-plain-100348

AllSkyFree
https://assetstore.unity.com/packages/2d/textures-materials/sky/allsky-free-10-sky-skybox-set-146014

Simple City pack plain
https://assetstore.unity.com/packages/3d/environments/urban/simple-city-pack-plain-100348

House Pack
https://assetstore.unity.com/packages/3d/environments/house-pack-35346

魔王魂
https://maoudamashii.jokersounds.com/

H/MIX GALLERY
http://www.hmix.net/music_gallery/feeling/cures.html

◆開発メンバーと担当作業
・新 碧惟(リング・プレイヤーの操作・マップ)
・鈴木 真輝(プレイヤー操作・マップ)
・そう きんい(当たり判定・タイトルシーン)
・大屋 しゅんご(マップ)
・大澤 諄也(プレイヤー・ビル・信号・道路・橋)
・田代 りょー（ビル）
・松本 晴香（エフェクト及びリング）
・久保田 ゆい（UI・背景作成）
